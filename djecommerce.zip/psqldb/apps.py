from django.apps import AppConfig


class PsqldbConfig(AppConfig):
    name = 'psqldb'
